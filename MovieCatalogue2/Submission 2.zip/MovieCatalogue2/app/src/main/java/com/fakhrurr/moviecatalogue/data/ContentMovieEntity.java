package com.fakhrurr.moviecatalogue.data;

public class ContentMovieEntity {
    private String mContent;

    public ContentMovieEntity(String content) {
        this.mContent = content;
    }

    public String getContent() {
        return mContent;
    }

    public void setContent(String mContent) {
        this.mContent = mContent;
    }
}
